<?php
App::uses('AppController', 'Controller');
/**
 * Formations Controller
 *
 */
class FormationsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */

public function beforeFilter() {
    parent::beforeFilter();
}

}
