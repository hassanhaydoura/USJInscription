<?php
App::uses('AppController', 'Controller');
/**
 * Dossierattributs Controller
 *
 */
class DossierattributsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */

   
      
   
   public function beforeFilter()
{
    parent::beforeFilter();
}


 
}
