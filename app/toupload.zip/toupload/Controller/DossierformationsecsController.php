<?php
App::uses('AppController', 'Controller');
/**
 * Dossierformationsecs Controller
 *
 */
class DossierformationsecsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */






}
