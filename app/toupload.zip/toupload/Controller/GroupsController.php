<?php
App::uses('AppController', 'Controller');
/**
 * Groups Controller
 *
 */
class GroupsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */

public function beforeFilter() 
{
    parent::beforeFilter();
}


}
