<?php
App::uses('AppController', 'Controller');
/**
 * Sections Controller
 *
 */
class SectionsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */
public function beforeFilter() 
{
    parent::beforeFilter();
}

}
