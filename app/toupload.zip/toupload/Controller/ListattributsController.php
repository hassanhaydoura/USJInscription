<?php
App::uses('AppController', 'Controller');
/**
 * Listattributs Controller
 *
 */
class ListattributsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */
public function beforeFilter() 
{
    parent::beforeFilter();
}
}
