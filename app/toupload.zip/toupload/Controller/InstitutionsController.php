<?php
App::uses('AppController', 'Controller');
/**
 * Institutions Controller
 *
 */
class InstitutionsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */

public function beforeFilter() {
    parent::beforeFilter();
}

}
