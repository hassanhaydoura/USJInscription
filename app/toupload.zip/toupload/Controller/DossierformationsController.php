<?php
App::uses('AppController', 'Controller');
/**
 * Dossierformations Controller
 *
 */
class DossierformationsController extends AppController {

/**
 * Scaffold
 *
 * @var mixed
 */




   public function beforeFilter()
{
    parent::beforeFilter();
}


}
